"""Run from the distributed QA folder: python validate_report.py (requires jsonschema, referencing)."""
from pathlib import Path
import collections,gzip,json,hashlib,re,itertools
import jsonschema
from referencing import Registry,Resource
ROOT=Path(__file__).resolve().parents[1]; QA=ROOT/'QA';R=ROOT/'Traffic.Report/definition'
load=lambda p:json.loads(p.read_text('utf-8-sig'))
meta=load(QA/'test_assets/model_metadata.json');schemas=json.loads(gzip.decompress((QA/'test_assets/schemas.json.gz').read_bytes()));reg=Registry()
for u,s in schemas.items():
    resource=Resource.from_contents(s);reg=reg.with_resource(u,resource).with_resource(s.get('$id',u),resource)
dims=meta['tables'];names=[m['name'] for t in dims.values() for m in t['measures']]
assert len(dims)==9 and len(names)==41 and len(meta['relationships'])==10
for f,h in meta['model_file_digests'].items():assert hashlib.sha256((ROOT/f).read_bytes()).hexdigest()==h,f
for r in meta['relationships']:
    assert r['fromColumn'] in dims[r['fromTable']]['columns'] and r['toColumn'] in dims[r['toTable']]['columns']
    assert r['fromTable'].startswith('Fact') and r['toTable'].startswith('Dim')
    assert r.get('fromCardinality','many')=='many' and r.get('toCardinality','one')=='one' and r.get('crossFilteringBehavior','oneDirection')=='oneDirection' and r.get('isActive',True)
supported={'actionButton':set(),'pageNavigator':set(),'scatterChart':{'Category','Series','X','Y','Tooltips'},'cardVisual':{'Data'},'clusteredBarChart':{'Category','Y','Series','Tooltips'},'clusteredColumnChart':{'Category','Y','Series','Tooltips'},'lineChart':{'Category','Y','Series','Tooltips'},'columnChart':{'Category','Y','Series','Tooltips'},'hundredPercentStackedBarChart':{'Category','Y','Series','Tooltips'},'pivotTable':{'Rows','Columns','Values'},'tableEx':{'Values'},'slicer':{'Values'},'textbox':set()}
def verify_json(file):
    value=load(file);schema=schemas[value['$schema']]
    v=jsonschema.Draft7Validator(schema,registry=reg)
    issues=list(v.iter_errors(value))
    if issues:raise AssertionError((str(file),[(list(e.path),e.message) for e in issues[:3]]))
    return value
def bind(field):
    typ,d=next(iter(field.items()));sr=d['Expression']['SourceRef'];t=sr['Entity'];col=d['Property']
    assert t in dims and (col in names and t=='مؤشرات المرور' if typ=='Measure' else col in dims[t]['columns']), (t,col,typ)
    return typ,t,col
def check_refs(e,entities=None):
    if isinstance(e,list):
        for v in e:check_refs(v,entities)
    elif isinstance(e,dict):
        if 'From' in e and 'Where' in e:entities={i['Name']:i['Entity'] for i in e['From']}
        for k,v in e.items():
            if k in ('Column','Measure') and isinstance(v,dict) and 'Property' in v:
                sr=v['Expression']['SourceRef'];t=sr['Entity'] if 'Entity' in sr else entities[sr['Source']]
                assert v['Property'] in (names if k=='Measure' else dims[t]['columns']), (t,v['Property'])
            check_refs(v,entities)
def intersect(a,b):return a['x']<b['x']+b['width'] and a['x']+a['width']>b['x'] and a['y']<b['y']+b['height'] and a['y']+a['height']>b['y']
pages=verify_json(R/'pages/pages.json');assert len(pages['pageOrder'])==7
def CounterOrCount(dic,kind):return sum(t==kind for t in dic.values())
count=types=collections.Counter();totbind=totinter=0;layouts=[];sync=collections.Counter();heat=0;filters=[];seen=set()
files=[ROOT/'Traffic.pbip',ROOT/'Traffic.Report/definition.pbir',ROOT/'Traffic.SemanticModel/definition.pbism',R/'version.json',R/'report.json']
for p in files:check_refs(verify_json(p))
assert (ROOT/load(files[0])['artifacts'][0]['report']['path']).resolve()==(ROOT/'Traffic.Report').resolve()
assert (files[1].parent/load(files[1])['datasetReference']['byPath']['path']).resolve()==(ROOT/'Traffic.SemanticModel').resolve()
for idx,pid in enumerate(pages['pageOrder']):
    path=R/'pages'/pid;page=verify_json(path/'page.json');assert page['name']==pid and (page['width'],page['height'])==(1920,1080)
    assert re.search('[\u0600-\u06ff]',page['displayName'])
    boxes=[];nodes={};bound=0;syncids={};cardids=set();dataids=set();cats=set()
    for f in sorted(path.glob('visuals/*/visual.json')):
        d=verify_json(f);assert d['name']==f.parent.name and d['name'] not in seen
        seen.add(d['name']);vis=d['visual'];typ=vis['visualType'];types[typ]+=1;nodes[d['name']]=typ
        assert typ in supported;check_refs(d)
        pos=d['position'];assert 0<=pos['x'] and 0<=pos['y'] and pos['x']+pos['width']<=page['width'] and pos['y']+pos['height']<=page['height']
        assert not any(intersect(pos,other) for other in boxes),f;boxes.append(pos)
        if typ=='pageNavigator':
            assert vis['objects']['fill'] and any(item.get('selector')=={'id':'selected'} for item in vis['objects']['fill']);continue
        if typ=='actionButton':
            assert vis['visualContainerObjects']['visualLink'][0]['properties']['type']['expr']['Literal']['Value']=="'ClearAllSlicers'";continue
        if typ=='textbox':
            pars=vis['objects']['general'][0]['properties']['paragraphs'];assert any(re.search('[\u0600-\u06ff]',s['value']) for p in pars for s in p['textRuns']);continue
        state=vis['query']['queryState'];assert state and set(state)<=supported[typ]
        refs=set()
        for role,rs in state.items():
            assert rs['projections']
            for pr in rs['projections']:
                k,t,col=bind(pr['field']);assert pr['queryRef']==t+'.'+col;refs.add(pr['queryRef']);bound+=1
                if role in ('X','Y') or typ=='cardVisual' or typ=='pivotTable' and role=='Values':assert k=='Measure'
                if role in ('Category','Series','Rows','Columns'):assert k=='Column'
        for obj in vis.get('query',{}).get('sortDefinition',{}).get('sort',[]):
            k,t,col=bind(obj['field']);assert t+'.'+col in refs
            if t in ('DimDate','DimPeriod'):assert obj['direction']=='Ascending'
        if typ not in ('slicer','cardVisual'):
            assert vis['visualContainerObjects']['title'][0]['properties']['text']['expr']['Literal']['Value']
        if typ=='scatterChart':
            assert state['Category']['projections'][0]['queryRef']=='FactCoverage.ساعة الحصر'
            assert state['Series']['projections'][0]['queryRef']=='DimDirection.اتجاه الحصر'
        if typ=='tableEx' and d.get('filterConfig'):
            widths=vis['objects']['columnWidth'];sel=[obj['selector']['metadata'] for obj in widths]
            assert set(sel)==refs and all('active' not in x for x in state['Values']['projections'])
            assert sum(float(o['properties']['value']['expr']['Literal']['Value'][:-1]) for o in widths)<=pos['width']-20
        if 'syncGroup' in vis:
            g=vis['syncGroup'];assert g['fieldChanges'] and g['filterChanges'];sync[g['groupName']]+=1;syncids[d['name']]=g['groupName']
        if typ=='slicer' and 'syncGroup' not in vis:cats.add(d['name'])
        if typ=='cardVisual':cardids.add(d['name'])
        if typ!='slicer':dataids.add(d['name'])
        for section in vis.get('objects',{}).get('values',[]):
            if 'backColor' in section['properties']:
                props=section['properties']['backColor']['solid']['color']['expr']['FillRule'];sref=props['Input']['SelectRef']['ExpressionName'];assert sref in refs and sref==section['selector']['metadata'];heat+=1
        for fc in d.get('filterConfig',{}).get('filters',[]):
            flag=bind(fc['field'])[2];filters.append(flag);assert fc['filter']['Where'][0]['Condition']['Comparison']['Right']['Literal']['Value']=='1L'
    links={(x['source'],x['target']):x['type'] for x in page['visualInteractions']}
    assert all(s in nodes and t in nodes and s!=t for s,t in links)
    for s in syncids:
        for t in dataids:assert links[s,t]=='DataFilter'
    for s in dataids-cardids:
        for t in cardids:assert links[s,t]=='NoFilter'
    if idx==3:
        assert len(cats)==1;comp=next(name for name,typ in nodes.items() if typ=='hundredPercentStackedBarChart')
        assert links[next(iter(cats)),comp]=='NoFilter'
    assert len(cardids)==[14,5,5,4,3,1,3][idx]
    assert CounterOrCount(nodes,'pageNavigator')==1 and CounterOrCount(nodes,'actionButton')==1
    texts=[load(f)['visual'].get('objects',{}).get('general',[]) for f in path.glob('visuals/*/visual.json')]
    assert sum('نتائج المسح الكامل — غير متأثرة بالفلاتر' in str(o) for o in texts)==1
    layouts.append({'page':page['displayName'],'visuals':len(nodes),'bound_fields':bound,'interactions':len(links)})
    totinter+=len(links);totbind+=bound
assert sync=={'التاريخ':7,'اتجاه الحصر':7,'فترة الرصد':7} and heat==4
assert collections.Counter(filters)=={'إظهار أعلى خمس ساعات':1,'إظهار فترات النشاط المتزامن المرتفع':2,'إظهار أعلى خمس ساعات عبور':1},filters
assert dims['DimPeriod']['columns']['الفترة الزمنية']['sortByColumn']=='ترتيب الفترة'
summary={'pages':layouts,'visual_count':sum(types.values()),'native_types':types,'bound_projections':totbind,'interaction_pairs':totinter,'sync_groups':sync,'conditional_matrices':heat,'overlaps':0,'unresolved_bindings':0,'report_schemas':'pass','native_desktop_render':'not run'}
(QA/'report_validation.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps(summary,ensure_ascii=False))
