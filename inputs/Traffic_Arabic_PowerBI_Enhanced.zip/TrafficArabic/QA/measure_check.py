"""Independent offline evaluator for the DAX operators used by this model only.
It reads TOM's deserialized expressions. This is a test harness, not a Tabular server."""
from __future__ import annotations
import re
from collections import defaultdict
from functools import lru_cache
from dataclasses import dataclass

TOKEN=re.compile(r'''\s*(?:(?P<table>'(?:[^']|'')*')|(?P<ref>\[[^\]]+\])|(?P<string>"(?:[^"]|"")*")|(?P<num>\d+(?:\.\d+)?)|(?P<word>[A-Za-z_][A-Za-z_.0-9]*)|(?P<op>\|\||&&|>=|[(),=&*<>+\-]))''')
class Parser:
    prec={'||':0,'&&':1,'>':2,'<':2,'*':5,'=':2,'>=':2,'&':3,'+':4,'-':4}
    def __init__(self,text):
        self.t=[];pos=0;text=text.strip()
        while pos<len(text):
            m=TOKEN.match(text,pos)
            if not m:raise ValueError(text[pos:pos+100])
            self.t.append((m.lastgroup,m[m.lastgroup]));pos=m.end()
        self.i=0
    def peek(self):return self.t[self.i][1] if self.i<len(self.t) else None
    def pop(self,expected=None):
        k,t=self.t[self.i];self.i+=1
        if expected is not None and t!=expected:raise ValueError((expected,t))
        return k,t
    def parse(self):
        out=self.value()
        if self.i!=len(self.t):raise ValueError(self.t[self.i:])
        return out
    def value(self,floor=0):
        typ,t=self.pop()
        if t=='VAR':
            declarations=[]
            while True:
                name=self.pop()[1];self.pop('=');declarations.append((name,self.value()))
                if self.peek()!='VAR':break
                self.pop('VAR')
            self.pop('RETURN');out=('let',declarations,self.value())
        elif t=='(':out=self.value();self.pop(')')
        elif t=='NOT':out=('not',self.value(5))
        elif typ=='table':
            tab=t[1:-1].replace("''","'")
            out=('col',(tab,self.pop()[1][1:-1])) if self.peek() and self.peek().startswith('[') else ('table',tab)
        elif typ=='ref':out=('ref',t[1:-1])
        elif typ=='num':out=('literal',float(t) if '.' in t else int(t))
        elif typ=='string':out=('literal',t[1:-1].replace('""','"'))
        elif typ=='word' and self.peek()=='(':
            self.pop('(');args=[]
            if self.peek()!=')':
                args.append(self.value())
                while self.peek()==',':self.pop(',');args.append(self.value())
            self.pop(')');out=('call',t,args)
        elif typ=='word':out=('var',t)
        else:raise ValueError((typ,t))
        while self.peek() in self.prec and self.prec[self.peek()]>=floor:
            op=self.pop()[1];out=('op',op,out,self.value(self.prec[op]+1))
        return out

def contextkey(f):return tuple(sorted((k,tuple(sorted(vals))) for k,vals in f.items()))
def rowkey(row):return tuple((k,v) for k,v in row.items())
class Evaluator:
    def __init__(self,model,tables):
        self.tab=tables;self.rels=defaultdict(list)
        for r in model['relationships']:self.rels[r['fromTable']].append(((r['fromTable'],r['fromColumn']),(r['toTable'],r['toColumn'])))
        self.ast={m['name']:Parser('\n'.join(m['expression']) if isinstance(m['expression'],list) else m['expression']).parse() for t in model['tables'] for m in t.get('measures',[])}
        self.dims={}
        for edges in self.rels.values():
            for _,(t,c) in edges:self.dims[(t,c)]={r[(t,c)]:r for r in self.tab[t]}
    @lru_cache(maxsize=65536)
    def active(self,table,fkey):
        f={k:set(v) for k,v in fkey}
        direct=[(k,v) for k,v in f.items() if k[0]==table]
        for src,dim in self.rels[table]:
            if any(k[0]==dim[0] for k in f):
                direct.append((src,{r[dim] for r in self.active(dim[0],fkey)}))
        return [r for r in self.tab[table] if all(r[k] in allowed for k,allowed in direct)]
    @lru_cache(maxsize=131072)
    def measured(self,name,fkey):
        return self.eval(self.ast[name],{k:set(vals) for k,vals in fkey},{},{})
    def transition(self,f,row):
        f=f.copy()
        for col,v in row.items():
            if isinstance(col,tuple):f[col]={v}
        return f
    def eval(self,n,f,env,row):
        kind=n[0]
        if kind=='literal':return n[1]
        if kind=='col':return row[n[1]]
        if kind=='table':return self.active(n[1],contextkey(f))
        if kind=='ref':
            if n[1].startswith('@'):return row[n[1]]
            return self.measured(n[1],contextkey(self.transition(f,row)))
        if kind=='var':return env[n[1]]
        if kind=='not':return not self.eval(n[1],f,env,row)
        if kind=='let':
            nested=dict(env)
            for name,val in n[1]:nested[name]=self.eval(val,f,nested,row)
            return self.eval(n[2],f,nested,row)
        if kind=='op':
            a=self.eval(n[2],f,env,row);b=self.eval(n[3],f,env,row)
            if n[1]=='=':return a==b or (a is None and b==0) or (b is None and a==0)
            if n[1]=='>=':return (a or 0)>=(b or 0)
            if n[1]=='||':return bool(a or b)
            if n[1]=='>':return (a or 0)>(b or 0)
            if n[1]=='<':return (a or 0)<(b or 0)
            if n[1]=='*':return (a or 0)*(b or 0)
            if n[1]=='&&':return bool(a and b)
            if n[1]=='&':return str(a)+str(b)
            if n[1]=='-':return (a or 0)-(b or 0)
            if n[1]=='+':return (a or 0)+(b or 0)
        op,args=n[1],n[2]
        ev=lambda a:self.eval(a,f,env,row)
        if op in ('SUM','DISTINCTCOUNT','VALUES','HASONEVALUE'):
            c=args[0][1];values=[r[c] for r in self.active(c[0],contextkey(f))]
            if op=='SUM':return sum(values) if values else None
            if op=='DISTINCTCOUNT':return len(set(values)) or None
            if op=='HASONEVALUE':return len(set(values))==1
            return [{c:v} for v in set(values)]
        if op=='SELECTEDVALUE':
            c=args[0][1];vs={r[c] for r in self.active(c[0],contextkey(f))}
            return next(iter(vs)) if len(vs)==1 else None
        if op=='TOPN':
            limit=ev(args[0]);items=list(ev(args[1]))
            for i in reversed(range(2,len(args),2)):
                items=sorted(items,key=lambda r:self.eval(args[i],f,env,r),reverse=args[i+1]==('var','DESC'))
            if len(items)<=limit:return items
            key=lambda r:tuple(self.eval(args[i],f,env,r) for i in range(2,len(args),2))
            boundary=key(items[limit-1]);return items[:limit]+[r for r in items[limit:] if key(r)==boundary]
        if op=='CONTAINS':
            vals=[(args[i][1],ev(args[i+1])) for i in range(1,len(args),2)]
            return any(all(r[c]==v for c,v in vals) for r in ev(args[0]))
        if op=='PERCENTILEX.INC':
            items=sorted(self.eval(args[1],f,env,r) for r in ev(args[0]));pct=ev(args[2])
            if not items:return None
            k=(len(items)-1)*pct;lo=int(k);hi=min(lo+1,len(items)-1)
            return items[lo]+(k-lo)*(items[hi]-items[lo])
        if op=='INT':
            import datetime as dt
            value=ev(args[0])
            return (value-dt.date(1899,12,30)).days if isinstance(value,dt.date) else int(value or 0)
        if op=='IF':return ev(args[1]) if ev(args[0]) else (ev(args[2]) if len(args)>2 else None)
        if op=='ISBLANK':return ev(args[0]) is None
        if op=='DIVIDE':
            numerator,denom=ev(args[0]),ev(args[1]);return numerator/denom if numerator is not None and denom else None
        if op=='COUNTROWS':return len(ev(args[0])) or None
        if op in ('CALCULATE','CALCULATETABLE'):
            new=self.transition(f,row)
            for clause in args[1:]:
                fun,cargs=clause[1],clause[2]
                if fun=='REMOVEFILTERS':new={k:v for k,v in new.items() if k[0]!=cargs[0][1]}
                elif fun=='ALLSELECTED':
                    tab=cargs[0][1];new={k:v for k,v in new.items() if k[0]!=tab}
                    new.update({k:v for k,v in self.selected.items() if k[0]==tab})
                elif fun=='KEEPFILTERS':
                    _,oper,lhs,rhs=cargs[0];assert oper=='='
                    col=lhs[1];one={ev(rhs)};new[col]=new.get(col,one)&one
                elif fun=='TREATAS':new[cargs[1][1]]={next(iter(r.values())) for r in ev(cargs[0])}
                else:raise ValueError(fun)
            return self.eval(args[0],new,env,{})
        if op=='INTERSECT':
            l,r=ev(args[0]),ev(args[1]);keys={rowkey(v) for v in r};return [v for v in l if rowkey(v) in keys]
        if op=='SUMMARIZE':
            table=args[0][1];cols=[a[1] for a in args[1:]];found={}
            for rec in self.active(table,contextkey(f)):
                d={}
                for c in cols:
                    if c[0]==table:d[c]=rec[c];continue
                    src,key=next(e for e in self.rels[table] if e[1][0]==c[0])
                    d[c]=self.dims[key][rec[src]][c]
                found[rowkey(d)]=d
            return list(found.values())
        if op=='ADDCOLUMNS':
            return [dict(r,**{ev(args[i]):self.eval(args[i+1],f,env,r) for i in range(1,len(args),2)}) for r in ev(args[0])]
        if op=='FILTER':return [r for r in ev(args[0]) if self.eval(args[1],f,env,r)]
        if op=='MAXX':
            vals=[self.eval(args[1],f,env,r) for r in ev(args[0])]
            return max((v for v in vals if v is not None),default=None)
        if op=='FORMAT':
            if ev(args[1])=='#,0':return format(ev(args[0]),',.0f')
            assert ev(args[1])=='yyyy-MM-dd'
            return ev(args[0]).isoformat()
        if op=='CONCATENATEX':
            items=ev(args[0]);delim=ev(args[2])
            for i in reversed(range(3,len(args),2)):
                assert args[i+1]==('var','ASC')
                items=sorted(items,key=lambda r:self.eval(args[i],f,env,r))
            return delim.join(str(self.eval(args[1],f,env,r)) for r in items)
        raise ValueError(op)
