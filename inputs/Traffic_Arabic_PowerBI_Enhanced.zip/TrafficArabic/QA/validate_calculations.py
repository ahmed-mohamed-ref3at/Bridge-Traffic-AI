"""Compare actual TOM-round-tripped measures to an independent raw workbook calculation.
Run with Python and openpyxl. These tests run outside the Microsoft DAX engine."""
from pathlib import Path
import collections, datetime as dt, json, math, statistics
import openpyxl
from measure_check import Evaluator, contextkey
ROOT=Path(__file__).resolve().parents[1];qa=ROOT/'QA'
meta=json.loads((qa/'test_assets/model_metadata.json').read_text())
model={'relationships':meta['relationships'],'tables':[dict(name=n,measures=t['measures']) for n,t in meta['tables'].items()]}
head,*rows=openpyxl.load_workbook(ROOT/'Sources/Traffic_Survey_Combined.xlsx',read_only=True,data_only=True).active.values
tables=collections.defaultdict(list)
def add(t,r):tables[t].append({(t,c):v for c,v in r.items()})
def timekey(s):
    clock,half=s.split(' - ')[0].split();h,m=map(int,clock.split(':'));return (h%12+12*(half=='م'))*60+m
def close(a,b):
    if isinstance(a,(int,float)) and isinstance(b,(int,float)):return math.isclose(a,b,rel_tol=1e-11,abs_tol=1e-9)
    return a==b
D='التاريخ';DIR='مفتاح الاتجاه';T='ترتيب الفترة';C='ترتيب الفئة';S='مفتاح الموعد';P='الفترة الزمنية'
directions={'سندوب - الصينية':1,'الصينية - سندوب':2}
categories=head[4:12];dates=sorted({r[1].date() for r in rows});periods=sorted({(timekey(r[3]),r[3]) for r in rows})
dimcols=[('DimDate',D),('DimDirection',DIR),('DimPeriod',T),('DimVehicleCategory',C)]
for d in dates:
    add('DimDate',{D:d,'السنة':d.year,'الشهر':'أكتوبر','رقم الشهر':d.month,'الشهر والسنة':'أكتوبر 2026','ترتيب الشهر والسنة':d.year*100+d.month,'اليوم':['الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت','الأحد'][d.weekday()],'ترتيب اليوم':(d.weekday()+2)%7+1,'يوم الشهر':d.day})
for x,label in periods:
    start=dt.datetime(1899,12,30)+dt.timedelta(minutes=x);add('DimPeriod',{T:x,P:label,'بداية الفترة':start,'نهاية الفترة':start+dt.timedelta(minutes=60)})
for i,label in enumerate(['من سندوب إلى الصينية','من الصينية إلى سندوب'],1):add('DimDirection',{DIR:i,'اتجاه الحصر':label})
for i,cat in enumerate(categories,1):add('DimVehicleCategory',{C:i,'فئة المركبة':cat if i<8 else 'فئة غير مسمّاة','اسم الفئة في المصدر':cat})
cover=collections.Counter();observations=[]
for r in rows:
    day=r[1].date();di=directions[r[16]];period=timekey(r[3]);slot=int(day.strftime('%Y%m%d'))*10000+period;base={'SourceRowKey':r[-1],D:day,DIR:di,T:period,S:slot}
    for i,v in enumerate(r[4:12],1):add('FactVehicleCount',dict(base,**{C:i,'عدد المركبات':v}))
    add('FactPedestrianCount',dict(base,**{'عدد مرات العبور':r[13],'م':r[0],'اسم الراصد':r[2],'مجموع المركبات':r[12],'مجموع المشاة':r[14],'الإجمالي العام':r[15]}))
    cover[(day,di,period,slot)]+=1
    observations.append((day,di,period,r[3],r[12],r[13],r[4:12]))
for (day,di,period,slot),n in cover.items():add('FactCoverage',{D:day,DIR:di,T:period,S:slot,'عدد السجلات':n,'دقائق الرصد':60})
add('مؤشرات المرور',{'مساعد':1})
def oracle(date=None,di=None,tm=None,ci=None):
    active=[r for r in observations if (date is None or r[0]==date) and (di is None or r[1]==di) and (tm is None or r[2]==tm)]
    def subtotal(rs):return sum(r[4] if ci is None else r[6][ci-1] for r in rs) if rs else None
    def coverage(rs):return len({(r[0],r[1],r[2]) for r in rs}) or None
    def div(a,b):return a/b if a is not None and b else None
    def peak(rs):
        by=collections.defaultdict(list)
        for r in rs:by[(r[0],r[2],r[3])].append(r)
        if not by:return None,None
        p=max(subtotal(v) for v in by.values())
        return p,' ، '.join(k[0].isoformat()+' | '+k[2] for k,v in sorted(by.items()) if subtotal(v)==p)
    dayn=len({r[0] for r in active}) or None;total=subtotal(active);denom=sum(r[4] for r in active) if active else None
    summary={'إجمالي المركبات المسجلة':total,'عدد مرات عبور المشاة':sum(r[5] for r in active) if active and di else None,'عدد فترات الرصد حسب الاتجاه':coverage(active),'عدد سجلات الحصر':len(active) or None,'عدد أيام الرصد':dayn,'عدد الساعات الزمنية المرصودة':len({(r[0],r[2]) for r in active}) or None,'متوسط عدد المركبات في الساعة':div(total,coverage(active)) if di else None,'عدد المركبات حسب الفئة':total,'نسبة فئة المركبات':div(total,denom),'متوسط المركبات في يوم رصد':div(total,dayn),'متوسط المركبات للفترة عبر الأيام':div(total,dayn) if tm is not None and di else None}
    p,label=peak(active) if di else (None,None);summary['أعلى عدد مركبات في ساعة مرصودة']=p;summary['تاريخ وفترة الذروة المرصودة']=label
    rs={d:[r for r in active if r[1]==d] for d in (1,2)};shared={(r[0],r[2]) for r in rs[1]} & {(r[0],r[2]) for r in rs[2]}
    summary['عدد الفترات المشتركة بين الاتجاهين']=len(shared) or None
    matched=[]
    for d,suffix in [(1,'من سندوب إلى الصينية'),(2,'من الصينية إلى سندوب')]:
        scoped=rs[d];v=subtotal(scoped);n=coverage(scoped);p,l=peak(scoped)
        for prefix,val in [('إجمالي المركبات',v),('مرات عبور المشاة',sum(r[5] for r in scoped) if scoped else None),('عدد فترات الرصد',n),('متوسط عدد المركبات في الساعة',div(v,n)),('أعلى عدد مركبات في ساعة',p),('تاريخ وفترة الذروة',l)]:summary[prefix+' '+suffix]=val
        value=subtotal([r for r in scoped if (r[0],r[2]) in shared]);matched.append(value);summary['المركبات في الفترات المشتركة '+suffix]=value
    diff=matched[0]-matched[1] if None not in matched else None
    summary['فرق المركبات بين الاتجاهين في الفترات المشتركة']=diff;summary['نسبة فرق المركبات في الفترات المشتركة']=div(diff,matched[1])
    return summary
def ctx(date,di,tm,ci):
    vals=[date,di,tm,ci];return {k:{v} for k,v in zip(dimcols,vals) if v is not None}

def band(h):return 'صباحًا' if h<12 else ('ظهرًا' if h<16 else 'مساءً')
def display_period(minute):
    h=minute//60;end=(h+1)%24;startband=band(h);endband=band(end)
    return f"{h%12 or 12}:00"+(' '+startband if startband!=endband else '')+f"–{end%12 or 12}:00 {endband}"
periodkeys={}
for r in tables['DimPeriod']:
    k=r[('DimPeriod',T)];r[('DimPeriod','فترة الرصد')]=display_period(k);periodkeys[k]=display_period(k)
coverage_names={}
for r in tables['FactCoverage']:
    day,di,k=[r[('FactCoverage',c)] for c in (D,DIR,T)]
    label=f"{day.day} أكتوبر {day.year} | {periodkeys[k]} | "+['من سندوب إلى الصينية','من الصينية إلى سندوب'][di-1]
    r[('FactCoverage','ساعة الحصر')]=label;coverage_names[(day,k,di)]=label
assert len(set(coverage_names.values()))==81 and len(set(periodkeys.values()))==10
engine=Evaluator(model,tables)
scopes=[(None,None,None,None)]+[(d,None,None,None) for d in dates]+[(None,d,None,None) for d in (1,2)]+[(None,None,t,None) for t,_ in periods]+[(None,None,None,c) for c in range(1,9)]+[(day,d,t,None) for day in dates for d in (1,2) for t,_ in periods]+[(None,d,None,c) for d in (1,2) for c in range(1,9)]+[(dates[2],1,720,c) for c in range(1,9)]
base_tests=new_tests=rank_tests=joint_tests=0
lookup=collections.defaultdict(lambda:[0,0])
for day,d,t,label,v,p,cv in observations:
    key=(day,t,d);lookup[key][0]+=v;lookup[key][1]+=p
thresholds={d:[statistics.quantiles([v[i] for k,v in lookup.items() if k[2]==d],n=4,method='inclusive')[2] for i in [0,1]] for d in [1,2]}
jointwindows={k for k,(v,p) in lookup.items() if v>=thresholds[k[2]][0] and p>=thresholds[k[2]][1]}
for scope in scopes:
    date,direction,tm,cat=scope;expected=oracle(*scope);current=ctx(*scope);engine.selected=current;engine.measured.cache_clear();f=contextkey(current)
    for name,want in expected.items():
        actual=engine.measured(name,f);assert close(actual,want),(name,scope,actual,want);base_tests+=1
    total=expected['إجمالي المركبات المسجلة'];n=expected['عدد فترات الرصد حسب الاتجاه'];ped=expected['عدد مرات عبور المشاة']
    filtered=[r for r in observations if (date is None or r[0]==date) and (direction is None or r[1]==direction) and (tm is None or r[2]==tm)]
    mix={('فئة غير مسمّاة' if i==7 else categories[i]):sum(row[6][i] for row in filtered) for i in range(8) if filtered and cat in (None,i+1)}
    top={k for k,v in mix.items() if v==max(mix.values())} if mix else set()
    got=engine.measured('فئة المركبات الأعلى تسجيلًا',f)
    assert set(got.split('، '))==top if got else not top,(scope,got,top)
    for name,want in [('متوسط المركبات لكل فترة اتجاهية',total/n if n and total is not None else None),('متوسط مرات العبور في الساعة',ped/n if n and ped is not None else None)]:
        assert close(engine.measured(name,f),want),(scope,name)
    new_tests+=3
# A report visual's cell filters sit inside slicer selections. Test best-five membership inside four scopes.
for rule in [{}, {('DimDirection',DIR):{2}}, {('DimDate',D):{dates[2]}}, {('DimPeriod',T):{720,780}}]:
    engine.selected=rule;engine.measured.cache_clear()
    scope=[k for k in lookup if all({('DimDate',D):k[0],('DimPeriod',T):k[1],('DimDirection',DIR):k[2]}[col] in vals for col,vals in rule.items())]
    best=set(sorted(scope,key=lambda k:(-lookup[k][0],k[0],k[1],k[2]))[:5])
    for day,tm,dr in scope:
        key=(day,tm,dr);f=contextkey(ctx(day,dr,tm,None))
        got=engine.measured('إظهار أعلى خمس ساعات',f);assert got==int(key in best),(key,got,best);rank_tests+=1
        got=engine.measured('إظهار فترات النشاط المتزامن المرتفع',f);assert got==int(key in jointwindows),(key,got,jointwindows);joint_tests+=1
assert len(jointwindows)==9 and sum(k[2]==1 for k in jointwindows)==4
summary=oracle();assert summary['إجمالي المركبات المسجلة']==127769 and summary['عدد سجلات الحصر']==96 and summary['عدد فترات الرصد حسب الاتجاه']==81
assert abs(sum(engine.measured('نسبة فئة المركبات',contextkey(ctx(None,None,None,c))) for c in range(1,9))-1)<1e-9
results={'method':'Offline evaluation of this model subset of DAX vs source-row oracle. No Microsoft query-engine execution.',
'baseline_measure_cases':base_tests,'new_kpi_cases':new_tests,'top5_membership_cases':rank_tests,'coactivity_membership_cases':joint_tests,'original_contexts':len(scopes),'all_measure_count':len(engine.ast),'all_study_totals':summary,'counted_windows':len(lookup),'full_sample_thresholds':thresholds,'simultaneous_windows':[[d.isoformat(),t,di,*lookup[(d,t,di)]] for d,t,di in sorted(jointwindows)],'top_five':[[d.isoformat(),t,di,*lookup[(d,t,di)]] for d,t,di in sorted(lookup,key=lambda k:(-lookup[k][0],k[0],k[1],k[2]))[:5]],'pass':True}
(qa/'calculation_validation.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print('PASS',base_tests,new_tests,rank_tests,joint_tests,results['top_five'],thresholds)

# Enhanced measures evaluated directly from the round-tripped expressions.
enh=0
for ctxrule in [{},{('DimDirection',DIR):{1}},{('DimDirection',DIR):{2}},{('DimDate',D):{dates[2]}},{('DimPeriod',T):{720,780}}]:
    engine.selected=ctxrule;engine.measured.cache_clear()
    eligible=[k for k in lookup if all({('DimDate',D):k[0],('DimPeriod',T):k[1],('DimDirection',DIR):k[2]}[c] in vs for c,vs in ctxrule.items())]
    best=sorted(eligible,key=lambda k:(-lookup[k][0],*k))[:5];pedbest=sorted(eligible,key=lambda k:(-lookup[k][1],*k))[:5]
    for k in eligible:
        day,minute,di=k;filters=ctx(day,di,minute,None);fk=contextkey(filters)
        assert engine.measured('ترتيب ساعة الذروة',fk)==(best.index(k)+1 if k in best else None)
        assert engine.measured('إظهار أعلى خمس ساعات عبور',fk)==int(k in pedbest)
        pointfilters={**ctxrule,('DimDirection',DIR):{di},('FactCoverage','ساعة الحصر'):{coverage_names[k]}}
        for m,value in zip(['مركبات نقطة الرصد','عبور نقطة الرصد'],lookup[k]):
            assert engine.measured(m,contextkey(pointfilters))==value,(k,m,value)
        enh+=4
for sc in scopes:
    rule=ctx(*sc);engine.selected=rule;engine.measured.cache_clear();f=contextkey(rule)
    expect=oracle(*sc);n=expect['عدد فترات الرصد حسب الاتجاه']
    expected_status='لا توجد مشاهدات ضمن الاختيار' if not n else 'فترات الرصد ضمن الاختيار  ·  '+format(n,',d')
    assert engine.measured('حالة اختيار الرصد',f)==expected_status
    cs=[sc[3]] if sc[3] else range(1,9)
    shares=[oracle(*sc[:3],i)['نسبة فئة المركبات'] for i in cs];target=max((x for x in shares if x is not None),default=None)
    assert close(engine.measured('حصة الفئة الأعلى تسجيلًا',f),target)
    enh+=2
results['enhanced_measure_comparisons']=enh;results['scatter_grain']='81 distinct date/period/direction captions; zero and missing tested separately'
(qa/'calculation_validation.json').write_text(json.dumps(results,ensure_ascii=False,indent=2))
print('Enhanced comparisons passed:',enh)
